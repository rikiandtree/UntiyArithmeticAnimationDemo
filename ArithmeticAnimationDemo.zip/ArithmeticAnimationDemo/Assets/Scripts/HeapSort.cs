﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;


namespace Demo {
    public class HeapSort : MonoBehaviour
    {
        private int[] arr;
        private GameObject[] goArr;
        private Vector3 tempPos;
        private Text titleText;
        private Color[] color;
        private int[] treePosY = { 180,60,60,-60,-60,-60,-60,-180,-180,-180 };
        private int[] treePosX = { 0, -200, 200, -300, -100, 100, 300, -350, -250, -150 };

        // Start is called before the first frame update
        void Start()
        {
            color = DataManager.color;
            arr = DataManager.arr;
            goArr = DataManager.goArr;
            tempPos = DataManager.tempPos;
            titleText = GameObject.Find("Title").GetComponent<Text>();
            int length = arr.Length;
            for (int i = 0; i < length; i++)
            {
                goArr[i].transform.localPosition = new Vector3(-450 + (i) * 100, 250, 0);
            }

            StartCoroutine(StartSort());

        }

        // Update is called once per frame
        void Update()
        {

        }
        Stack<int> goColor = new Stack<int>();
        IEnumerator StartSort()
        {
            int length = arr.Length;
            yield return new WaitForSeconds(1);
            for (int i = 0; i < length; i++)
            {
                goArr[i].transform.DOLocalMove( new Vector3(treePosX[i], treePosY[i], 0),0.3f);
                yield return new WaitForSeconds(0.3f);
            }
            titleText.text = "开始构建最大堆";

            for (int i = length/2; i >=0; i--)
            {
                int j = i;

                while (j< length)
                {
                    SetGoColor(goArr[j], color[3]);
                    goColor.Push(j);
                    int left = 2 * j + 1;
                    int right = 2 * j + 2;
                    int cur = j;
                    if (left < length)
                    {
                        SetGoColor(goArr[left], color[3]);
                        goColor.Push(left);
                        cur = left;
                        if (right< length)
                        {
                            SetGoColor(goArr[right], color[3]);
                            goColor.Push(right);
                            if (arr[left]<arr[right])
                            {
                                cur = right;
                            }
                        }
                    }

                    if (arr[j] < arr[cur])
                    {
                        int temp = arr[cur];
                        arr[cur] = arr[j];
                        arr[j] = temp;
                        GameObject go1 = goArr[cur];
                        GameObject go2 = goArr[j];
                        go1.transform.DOLocalMove(new Vector3(treePosX[j], treePosY[j], 0), 0.5f);
                        go2.transform.DOLocalMove(new Vector3(treePosX[cur], treePosY[cur], 0), 0.5f);
                        goArr[cur] = go2;
                        goArr[j] = go1;
                        yield return new WaitForSeconds(0.5f);
                        j = cur;
                    }else
                    {
                        while (goColor.Count > 0)
                        {
                            SetGoColor(goArr[goColor.Pop()], color[0]);

                        }
                        yield return new WaitForSeconds(0.5f);
                        break;
                    }
                    while (goColor.Count > 0)
                    {
                        SetGoColor(goArr[goColor.Pop()], color[0]);
                    }
                    yield return new WaitForSeconds(0.5f);



                }
            }
            titleText.text = "自上而下调整堆";

            int index = length - 1;
            while (index>0)
            {
                int temp1 = arr[index];
                arr[index] = arr[0];
                arr[0] = temp1;

                goArr[0].transform.DOLocalMove(new Vector3(treePosX[index], treePosY[index], 0), 0.5f);
                goArr[index].transform.DOLocalMove(new Vector3(treePosX[0], treePosY[0], 0), 0.5f);

                GameObject goTemp1 = goArr[0];
                goArr[0] = goArr[index];
                goArr[index] = goTemp1;
                SetGoColor(goArr[index], color[4]);
              
                    int j = 0;

                    while (j < index)
                    {
                        SetGoColor(goArr[j], color[3]);
                        goColor.Push(j);
                        int left = 2 * j + 1;
                        int right = 2 * j + 2;
                        int cur = j;
                        if (left < index)
                        {
                            SetGoColor(goArr[left], color[3]);
                            goColor.Push(left);
                            cur = left;
                            if (right < index)
                            {
                                SetGoColor(goArr[right], color[3]);
                                goColor.Push(right);
                                if (arr[left] < arr[right])
                                {
                                    cur = right;
                                }
                            }
                        }

                        if (arr[j] < arr[cur])
                        {
                            int temp = arr[cur];
                            arr[cur] = arr[j];
                            arr[j] = temp;
                            GameObject go1 = goArr[cur];
                            GameObject go2 = goArr[j];
                            go1.transform.DOLocalMove(new Vector3(treePosX[j], treePosY[j], 0), 0.5f);
                            go2.transform.DOLocalMove(new Vector3(treePosX[cur], treePosY[cur], 0), 0.5f);
                            goArr[cur] = go2;
                            goArr[j] = go1;
                            yield return new WaitForSeconds(0.5f);
                            j = cur;
                        }
                        else
                        {
                            while (goColor.Count > 0)
                            {
                                SetGoColor(goArr[goColor.Pop()], color[0]);

                            }
                            yield return new WaitForSeconds(0.5f);
                            break;
                        }
                        while (goColor.Count > 0)
                        {
                            SetGoColor(goArr[goColor.Pop()], color[0]);
                        }
                        yield return new WaitForSeconds(0.5f);



                    

                }

          
            }




        }


        private void SetGoColor(GameObject go,Color color)
        {
            Image image = go.GetComponent<Image>();
            image.color = color;
        }
    }
}

