﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;


namespace Demo {
    public class ShellSort : MonoBehaviour
    {
        private int[] arr;
        private GameObject[] goArr;
        private Vector3 tempPos;
        private Text titleText;
        private Color[] color;
        // Start is called before the first frame update
        void Start()
        {
            color = DataManager.color;
            arr = DataManager.arr;
            goArr = DataManager.goArr;
            tempPos = DataManager.tempPos;
            titleText = GameObject.Find("Title").GetComponent<Text>();
            StartCoroutine(StartSort());

        }

        // Update is called once per frame
        void Update()
        {

        }

        IEnumerator StartSort()
        {
            int length = arr.Length;
            yield return new WaitForSeconds(1);
            int gap = length / 2;
           
            while (gap>0)
            {

                titleText.text = "原数组如下";
                for (int i = 0; i < length; i++)
                {
                    GameObject tempGo = goArr[i];
                    Image image = tempGo.GetComponent<Image>();
                    image.color = color[0];
                    tempGo.transform.DOLocalMoveY(0, 0.2f);

                }
                yield return new WaitForSeconds(0.5f);
                titleText.text = "间隔为" + gap.ToString() + "分组,并组内插入排序";
                for (int i = 0; i < length; i++)
                {
                    GameObject tempGo = goArr[i];
                    int y = (i) % gap;
                    Image image = tempGo.GetComponent<Image>();
                    image.color = color[y];
                    tempGo.transform.DOLocalMoveY(-(y)*50, 0.2f);
                }

                yield return new WaitForSeconds(0.5f);

                for (int i = gap; i < length; i++)
                {
                    int j = i - gap;
                    int temp = arr[i];
                    GameObject tempGo = goArr[i];
                    tempGo.transform.DOLocalMove(tempPos, 0.3f);
                    yield return new WaitForSeconds(0.4f);
                    while (j >= 0 && temp < arr[j])
                    {
                        GameObject go1 = goArr[j + gap];
                        GameObject go2 = goArr[j];
                        arr[j + gap] = arr[j];
                        goArr[j + gap] = goArr[j];
                        go2.transform.DOLocalMoveX(-450 + 100 * (j + gap), 0.2f);
                        j=j-gap;
                        yield return new WaitForSeconds(0.3f);

                    }
                    arr[j + gap] = temp;
                    goArr[j + gap] = tempGo;
                    int y = (j + gap) % gap;
                    tempGo.transform.DOLocalMove(new Vector3(-450 + 100 * (j + gap), -(y) * 50, 0), 0.3f);

                    yield return new WaitForSeconds(0.4f);
                }

                gap = gap / 2;
                yield return new WaitForSeconds(0.4f);
            }


            titleText.text = "间隔为1排序后，排序完成";

            yield return null;
        }
    }
}

