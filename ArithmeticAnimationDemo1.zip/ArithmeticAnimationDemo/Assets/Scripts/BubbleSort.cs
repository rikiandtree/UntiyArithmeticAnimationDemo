﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;


namespace Demo {
    public class BubbleSort : MonoBehaviour
    {
        private int[] arr;
        private GameObject[] goArr;
        private Vector3 tempPos;
        private Text titleText;
        private Transform theTag;
        // Start is called before the first frame update
        void Start()
        {
            arr = DataManager.arr;
            goArr = DataManager.goArr;
            tempPos = DataManager.tempPos;
            titleText = GameObject.Find("Title").GetComponent<Text>();
            theTag = GameObject.Find("Tag").transform;


            StartCoroutine(StartSort());

        }

        // Update is called once per frame
        void Update()
        {

        }

        IEnumerator StartSort()
        {
            int length = arr.Length;
            yield return new WaitForSeconds(1);

            for (int i = 0; i < length-1; i++)
            {
                titleText.text = "第"+(i+1)+"轮，最大数往前浮";

                for (int j = 0; j < length-i-1; j++)
                {
                    DataManager.SetGoColor(goArr[j], 3);
                    DataManager.SetGoColor(goArr[j+1], 3);

                    if (arr[j]>arr[j+1])
                    {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;

                        GameObject go1 = goArr[j];
                        GameObject go2 = goArr[j+1];

                        go1.transform.DOLocalMoveX(-450 + (j+1) * 100, 0.3f);
                        go2.transform.DOLocalMoveX(-450 + (j) * 100, 0.3f);
                        goArr[j] = go2;
                        goArr[j + 1] = go1;
                    }
                    DataManager.SetGoColor(goArr[j], 0);
                    yield return new WaitForSeconds(0.8f);
                }
                DataManager.SetGoColor(goArr[length-i-1], 4);

                       

                }
            yield return new WaitForSeconds(0.8f);
            titleText.text = "排序完成";
            for (int i = 0; i < length; i++)
            {
                DataManager.SetGoColor(goArr[i], 0);
            }
            yield return null;
        }
    }
}

