﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Demo
{
    public  class DataManager : MonoBehaviour
    {
        public static DataManager Instance;
        public static int[] arr;
        public static GameObject[] goArr;
        public static Vector3 tempPos;
        public static Color[] color = { Color.red, Color.blue, Color.grey, Color.green, Color.cyan };

        void Awake()
        {
            Instance = this;

            arr = new int[10];
            goArr = new GameObject[10];
            tempPos = GameObject.Find("Temp").transform.localPosition;
            for (int i = 0; i < 10; i++)
            {
                GameObject go = GameObject.Find((i).ToString());
                goArr[i] = go;
                arr[i] = i;
            }

            for (int i = 0; i < 10; i++)
            {
                int temp = arr[i];
                int index = Random.Range(0, 9);
                arr[i] = arr[index];
                arr[index] = temp;
            }

            for (int i = 0; i < 10; i++)
            {

                GameObject go = goArr[i];
                int num = arr[i];
                go.transform.localPosition = new Vector3(-450 + 100 * i, 0, 0);
                go.name = num.ToString();
                Text text = go.transform.Find("Text").GetComponent<Text>();
                text.text = num.ToString();
            }

        }


        public static void SetGoColor(GameObject go,int index)
        {
            Image image = go.GetComponent<Image>();
            image.color = color[index];
        }

    }
}

