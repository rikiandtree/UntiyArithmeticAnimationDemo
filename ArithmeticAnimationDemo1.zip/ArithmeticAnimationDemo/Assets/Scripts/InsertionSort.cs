﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

namespace Demo {
    public class InsertionSort : MonoBehaviour
    {
        private int[] arr;
        private GameObject[] goArr;
        private Vector3 tempPos;



        // Start is called before the first frame update
        void Start()
        {
            arr = DataManager.arr;
            goArr = DataManager.goArr;
            tempPos = DataManager.tempPos;

            StartCoroutine(StartSort());
        }

        // Update is called once per frame
        void Update()
        {

        }

        IEnumerator StartSort()
        {
            int length = arr.Length;
            yield return new WaitForSeconds(1);

            for (int i = 1; i < length; i++)
            {
                int j = i - 1;
                int temp = arr[i];
                GameObject tempGo = goArr[i];
                tempGo.transform.DOLocalMove(tempPos, 0.3f);
                yield return new WaitForSeconds(0.4f);
                while (j >= 0 && temp < arr[j])
                {
                    GameObject go1 = goArr[j + 1];
                    GameObject go2 = goArr[j];
                    arr[j + 1] = arr[j];
                    goArr[j + 1] = goArr[j];
                    go2.transform.DOLocalMove(new Vector3(-450 + 100 * (j + 1), 0, 0), 0.2f);
                    j--;
                    yield return new WaitForSeconds(0.3f);

                }
                arr[j + 1] = temp;
                goArr[j + 1] = tempGo;
                tempGo.transform.DOLocalMove(new Vector3(-450 + 100 * (j + 1), 0, 0), 0.3f);

                yield return new WaitForSeconds(0.4f);
            }


            yield return null;
        }
    }
}
