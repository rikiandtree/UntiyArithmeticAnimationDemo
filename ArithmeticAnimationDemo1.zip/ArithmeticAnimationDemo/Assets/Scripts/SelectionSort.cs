﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;


namespace Demo {
    public class SelectionSort : MonoBehaviour
    {
        private int[] arr;
        private GameObject[] goArr;
        private Vector3 tempPos;
        private Text titleText;
        private Transform theTag;
        // Start is called before the first frame update
        void Start()
        {
            arr = DataManager.arr;
            goArr = DataManager.goArr;
            tempPos = DataManager.tempPos;
            titleText = GameObject.Find("Title").GetComponent<Text>();
            theTag = GameObject.Find("Tag").transform;
            Text text= theTag.GetComponent<Text>();
            text.text = "i";

            StartCoroutine(StartSort());

        }

        // Update is called once per frame
        void Update()
        {

        }

        IEnumerator StartSort()
        {
            int length = arr.Length;
            yield return new WaitForSeconds(1);

            for (int i = 0; i < length-1; i++)
            {
                titleText.text = "目前最小数";
                int temp = arr[i];
                int index = i;
                theTag.transform.DOLocalMoveX(-450 + (index) * 100, 0.3f);
                yield return new WaitForSeconds(0.3f);
                GameObject tempGo = goArr[i];
                tempGo.transform.DOLocalMove(tempPos, 0.3f);
                
                for (int j = i+1; j < length; j++)
                {
                    GameObject curGo= goArr[j];
                    curGo.transform.DOShakeScale(0.3f);
                    yield return new WaitForSeconds(0.5f);
                    if (arr[j]< temp)
                    {
                        tempGo.transform.DOLocalMove(new Vector3(-450 + (index ) * 100, 0, 0), 0.1f);
                        curGo.transform.DOLocalMove(tempPos, 0.2f);
                        temp = arr[j];
                        tempGo = curGo;
                        index = j;
                        yield return new WaitForSeconds(0.2f);

                    }

                }
                GameObject go = goArr[i];
                arr[index] = arr[i];
                arr[i] = temp;
                goArr[index] = go;
                goArr[i] = tempGo;
                tempGo.transform.DOLocalMove(new Vector3(-450 + (i) * 100, 0, 0), 0.2f);
                go.transform.DOLocalMove(new Vector3(-450 + (index) * 100, 0, 0), 0.2f);

                yield return new WaitForSeconds(0.3f);
                DataManager.SetGoColor(goArr[i], 4);
            }
            DataManager.SetGoColor(goArr[length-1], 4);
            titleText.text = "排序完成";

            for (int i = 0; i < length; i++)
            {
                DataManager.SetGoColor(goArr[i], 0);
            }
            Text text = theTag.GetComponent<Text>();
            text.text = "";
            yield return null;
        }
    }
}

